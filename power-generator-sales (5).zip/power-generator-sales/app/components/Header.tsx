import Link from 'next/link'
import { Power } from 'lucide-react'

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Power className="h-8 w-8 text-green-500" />
          <span className="text-xl font-bold text-gray-800">PowerAnywhere</span>
        </Link>
        <div className="space-x-4">
          <Link href="#features" className="text-gray-600 hover:text-green-500">Features</Link>
          <Link href="#product" className="text-gray-600 hover:text-green-500">Product</Link>
          <Link href="#testimonials" className="text-gray-600 hover:text-green-500">Testimonials</Link>
          <Link href="#cta" className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition duration-300">
            Buy Now
          </Link>
        </div>
      </nav>
    </header>
  )
}

