import Image from 'next/image'

export default function ProductShowcase() {
  return (
    <section id="product" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Revolutionary Product</h2>
        <div className="flex flex-col lg:flex-row items-center justify-center space-y-8 lg:space-y-0 lg:space-x-12">
          <div className="lg:w-1/2 transition-opacity duration-500 ease-in-out opacity-0 animate-fade-in">
            <Image 
              src="/placeholder.svg?height=400&width=400" 
              alt="PowerAnywhere Generator in Action" 
              width={400} 
              height={400}
              className="rounded-lg shadow-lg mx-auto"
            />
          </div>
          <div className="lg:w-1/2 transition-opacity duration-500 ease-in-out opacity-0 animate-fade-in delay-300">
            <h3 className="text-2xl font-semibold mb-4">PowerAnywhere Handheld Generator</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <span className="bg-green-500 rounded-full p-1 mr-3"></span>
                Generates up to 100W of power
              </li>
              <li className="flex items-center">
                <span className="bg-green-500 rounded-full p-1 mr-3"></span>
                Weighs only 2 pounds
              </li>
              <li className="flex items-center">
                <span className="bg-green-500 rounded-full p-1 mr-3"></span>
                Charges in just 2 hours
              </li>
              <li className="flex items-center">
                <span className="bg-green-500 rounded-full p-1 mr-3"></span>
                Multiple charging ports (USB-C, USB-A, AC outlet)
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

