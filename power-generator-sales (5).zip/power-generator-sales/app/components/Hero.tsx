'use client'

import Image from 'next/image'
import { useEffect, useRef, useState } from 'react'

export default function Hero() {
  const [scrollY, setScrollY] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const brightness = Math.max(1 - scrollY / 300, 0.5)

  return (
    <section 
      ref={heroRef}
      className="relative h-screen flex items-center justify-center overflow-hidden transition-all duration-300 ease-in-out"
      style={{ filter: `brightness(${brightness})` }}
    >
      <div className="container mx-auto px-4 z-10">
        <div 
          className="text-center opacity-0 translate-y-4 animate-fade-in-up"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Power Anywhere, Anytime
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8">
            Introducing the revolutionary handheld power generator that attaches to anything. Never be without power again.
          </p>
          <a href="#cta" className="bg-green-500 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-green-600 transition duration-300">
            Get Yours Now
          </a>
        </div>
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-600 opacity-75"></div>
      <Image 
        src="/placeholder.svg?height=1080&width=1920" 
        alt="PowerAnywhere in action" 
        layout="fill"
        objectFit="cover"
        className="absolute inset-0"
        priority
      />
    </section>
  )
}

