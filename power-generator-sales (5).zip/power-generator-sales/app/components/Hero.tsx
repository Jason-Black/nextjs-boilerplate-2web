import Image from 'next/image'
import { motion } from 'framer-motion'

export default function Hero() {
  return (
    <section className="container mx-auto px-4 py-20 flex flex-col md:flex-row items-center">
      <motion.div 
        className="md:w-1/2 mb-10 md:mb-0"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
          Power Anywhere, Anytime
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Introducing the revolutionary handheld power generator that attaches to anything. Never be without power again.
        </p>
        <a href="#cta" className="bg-green-500 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-green-600 transition duration-300">
          Get Yours Now
        </a>
      </motion.div>
      <motion.div 
        className="md:w-1/2"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Image 
          src="/placeholder.svg?height=400&width=400" 
          alt="PowerAnywhere Handheld Generator" 
          width={400} 
          height={400}
          className="rounded-lg shadow-lg"
        />
      </motion.div>
    </section>
  )
}

