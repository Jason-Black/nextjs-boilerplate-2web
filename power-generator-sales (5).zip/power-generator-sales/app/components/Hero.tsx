'use client'

import Image from 'next/image'
import { motion, useScroll, useTransform } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

export default function Hero() {
  const [isMounted, setIsMounted] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollY } = useScroll()
  const brightness = useTransform(scrollY, [0, 300], [1, 0.5])

  useEffect(() => {
    setIsMounted(true)
  }, [])

  if (!isMounted) {
    return null
  }

  return (
    <motion.section 
      ref={heroRef}
      className="relative h-screen flex items-center justify-center overflow-hidden"
      style={{ brightness }}
    >
      <div className="container mx-auto px-4 z-10">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Power Anywhere, Anytime
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8">
            Introducing the revolutionary handheld power generator that attaches to anything. Never be without power again.
          </p>
          <a href="#cta" className="bg-green-500 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-green-600 transition duration-300">
            Get Yours Now
          </a>
        </motion.div>
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-600 opacity-75"></div>
      <Image 
        src="/placeholder.svg?height=1080&width=1920" 
        alt="PowerAnywhere in action" 
        layout="fill"
        objectFit="cover"
        className="absolute inset-0"
        priority
      />
    </motion.section>
  )
}

