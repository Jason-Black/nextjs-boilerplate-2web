import { motion } from 'framer-motion'

export default function CTA() {
  return (
    <section id="cta" className="py-20 bg-green-500">
      <div className="container mx-auto px-4 text-center">
        <motion.h2 
          className="text-3xl md:text-4xl font-bold text-white mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          Ready to Power Your Life?
        </motion.h2>
        <motion.p 
          className="text-xl text-white mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          viewport={{ once: true }}
        >
          Get your PowerAnywhere generator today and never worry about running out of power again.
        </motion.p>
        <motion.a 
          href="#" 
          className="inline-block bg-white text-green-500 px-8 py-3 rounded-md text-lg font-semibold hover:bg-gray-100 transition duration-300"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          Order Now
        </motion.a>
      </div>
    </section>
  )
}

